import { notFound } from "next/navigation";
import { surahs } from "@/data/surahs";
import { sampleAyahs } from "@/data/sample-ayahs";
import { ReaderControls } from "@/components/ReaderControls";

export function generateStaticParams() {
  return surahs.map((s) => ({ surah: String(s.number) }));
}

export default async function SurahPage({ params }: { params: Promise<{ surah: string }> }) {
  const { surah } = await params;
  const number = Number(surah);
  const current = surahs.find((s) => s.number === number);
  if (!current) notFound();

  const ayahs = number === 1 ? sampleAyahs : sampleAyahs;

  return (
    <main className="mx-auto max-w-4xl px-5 py-10 md:px-8">
      <div className="rounded-[2rem] border border-ink/10 bg-white p-7 text-center shadow-soft md:p-10">
        <p className="text-sm uppercase tracking-[.25em] text-gold">Surah {current.number}</p>
        <h1 className="quran-arabic mt-3 text-5xl text-forest">{current.arabic}</h1>
        <p className="mt-2 text-lg font-medium">{current.english}</p>
        <p className="mt-1 text-sm text-ink/45">{current.translation} · {current.revelation} · {current.ayahs} Ayahs</p>
      </div>

      <ReaderControls />

      <section className="mt-8 space-y-5">
        {ayahs.map((ayah) => (
          <article key={ayah.number} className="rounded-[1.75rem] border border-ink/10 bg-white p-6 md:p-8">
            <div className="flex items-center justify-between">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-ivory text-xs text-forest">{ayah.number}</span>
              <button className="text-xs text-ink/40 hover:text-forest">Bookmark</button>
            </div>
            <div className="quran-arabic mt-7 text-right text-3xl leading-[2.4] text-ink md:text-4xl">{ayah.arabic}</div>
            <div className="mt-7 border-t border-ink/5 pt-6">
              <div className="text-sm font-semibold text-forest">Urdu</div>
              <p className="mt-2 text-right text-lg leading-8" dir="rtl">{ayah.urdu}</p>
              <div className="mt-5 text-sm font-semibold text-forest">Roman Urdu</div>
              <p className="mt-2 leading-7 text-ink/65">{ayah.romanUrdu}</p>
              <div className="mt-5 text-sm font-semibold text-forest">English</div>
              <p className="mt-2 leading-7 text-ink/65">{ayah.english}</p>
            </div>
          </article>
        ))}
      </section>
    </main>
  );
}
