export const sampleAyahs = [
  {
    number: 1,
    arabic: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
    urdu: "اللہ کے نام سے جو نہایت مہربان، بے حد رحم والا ہے۔",
    romanUrdu: "Allah ke naam se jo nihayat meherban, be-had reham wala hai.",
    english: "In the name of Allah, the Most Compassionate, the Most Merciful."
  },
  {
    number: 2,
    arabic: "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ",
    urdu: "سب تعریفیں اللہ ہی کے لیے ہیں جو تمام جہانوں کا رب ہے۔",
    romanUrdu: "Sab tareefein Allah hi ke liye hain jo tamam jahanon ka Rabb hai.",
    english: "All praise is for Allah, Lord of the worlds."
  },
  {
    number: 3,
    arabic: "الرَّحْمَٰنِ الرَّحِيمِ",
    urdu: "نہایت مہربان، بے حد رحم والا۔",
    romanUrdu: "Nihayat meherban, be-had reham wala.",
    english: "The Most Compassionate, Most Merciful."
  },
  {
    number: 4,
    arabic: "مَالِكِ يَوْمِ الدِّينِ",
    urdu: "روزِ جزا کا مالک۔",
    romanUrdu: "Roz-e-jaza ka Malik.",
    english: "Master of the Day of Judgment."
  }
];
