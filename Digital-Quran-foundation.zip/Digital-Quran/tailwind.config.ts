import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        ink: "#171815",
        ivory: "#f8f5ed",
        forest: "#173f35",
        gold: "#b58a45",
        mist: "#e9e5d9"
      },
      fontFamily: {
        sans: ["var(--font-inter)", "Arial", "sans-serif"],
        arabic: ["var(--font-amiri)", "serif"]
      },
      boxShadow: {
        soft: "0 20px 60px rgba(23, 24, 21, 0.08)"
      }
    }
  },
  plugins: []
};

export default config;
