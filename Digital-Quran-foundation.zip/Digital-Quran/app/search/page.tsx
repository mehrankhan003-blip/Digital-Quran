 "use client";

import { Search } from "lucide-react";
import { useMemo, useState } from "react";
import { surahs } from "@/data/surahs";

export default function SearchPage() {
  const [query, setQuery] = useState("");
  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];
    return surahs.filter(s => `${s.english} ${s.translation} ${s.arabic}`.toLowerCase().includes(q));
  }, [query]);

  return (
    <main className="mx-auto max-w-4xl px-5 py-12 md:px-8">
      <p className="text-sm uppercase tracking-[.2em] text-gold">Discovery</p>
      <h1 className="mt-2 text-4xl font-semibold">Search the Quran</h1>
      <div className="mt-8 flex items-center gap-3 rounded-2xl border border-ink/10 bg-white px-4 py-3 shadow-sm">
        <Search size={19} className="text-ink/35"/>
        <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search Surah, Arabic, English..." className="w-full bg-transparent outline-none placeholder:text-ink/30"/>
      </div>
      <div className="mt-6 space-y-3">
        {results.map(s => <div key={s.number} className="rounded-2xl border border-ink/10 bg-white p-5">{s.number}. {s.english} — {s.translation}</div>)}
        {query && !results.length && <p className="py-10 text-center text-ink/45">No results in the current starter dataset.</p>}
      </div>
    </main>
  );
}
