# Digital Quran

World-class Quran reading, translation and recitation experience.

## Stack

- Next.js App Router
- TypeScript
- Tailwind CSS
- React
- Vercel-ready architecture
- Installable PWA foundation

## Current milestone

**Foundation / UI prototype**

The current repository contains the product shell, responsive design system, Surah navigation, reader experience, translation layout, search shell, settings shell and audio-control architecture.

### Important

The included ayahs are **starter UI data only**. Before production release, the Quran text and translations must be replaced/validated against reputable canonical data sources. Never treat the starter dataset as the complete Quran.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Roadmap

1. Canonical Quran data layer
2. Complete 114-surah navigation
3. Urdu / Roman Urdu / English translations
4. Reciter catalog and audio CDN
5. Ayah synchronized playback
6. Mushaf mode
7. Bookmarks / notes / history
8. Khatmah planner
9. Hifz mode
10. Offline PWA
11. Accessibility + SEO
12. Production QA
