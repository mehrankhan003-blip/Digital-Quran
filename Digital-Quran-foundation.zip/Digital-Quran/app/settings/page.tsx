export default function SettingsPage() {
  return (
    <main className="mx-auto max-w-3xl px-5 py-12 md:px-8">
      <p className="text-sm uppercase tracking-[.2em] text-gold">Preferences</p>
      <h1 className="mt-2 text-4xl font-semibold">Reading settings</h1>
      <div className="mt-8 divide-y divide-ink/5 overflow-hidden rounded-2xl border border-ink/10 bg-white">
        {[
          ["Translation", "Urdu + Roman Urdu"],
          ["Reading mode", "Focused"],
          ["Theme", "System"],
          ["Arabic font", "Amiri"],
          ["Reciter", "To be connected"],
          ["Playback", "Ayah by Ayah"]
        ].map(([a,b]) => <div key={a} className="flex items-center justify-between p-5"><span>{a}</span><span className="text-sm text-ink/45">{b}</span></div>)}
      </div>
    </main>
  );
}
