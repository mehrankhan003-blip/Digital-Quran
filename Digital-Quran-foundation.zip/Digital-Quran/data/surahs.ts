export type Surah = {
  number: number;
  arabic: string;
  english: string;
  translation: string;
  ayahs: number;
  revelation: "Makki" | "Madani";
};

export const surahs: Surah[] = [
  { number: 1, arabic: "الفاتحة", english: "Al-Fatihah", translation: "The Opening", ayahs: 7, revelation: "Makki" },
  { number: 2, arabic: "البقرة", english: "Al-Baqarah", translation: "The Cow", ayahs: 286, revelation: "Madani" },
  { number: 3, arabic: "آل عمران", english: "Aal-E-Imran", translation: "The Family of Imran", ayahs: 200, revelation: "Madani" },
  { number: 4, arabic: "النساء", english: "An-Nisa", translation: "The Women", ayahs: 176, revelation: "Madani" },
  { number: 5, arabic: "المائدة", english: "Al-Ma'idah", translation: "The Table Spread", ayahs: 120, revelation: "Madani" },
  { number: 6, arabic: "الأنعام", english: "Al-An'am", translation: "The Cattle", ayahs: 165, revelation: "Makki" }
];
