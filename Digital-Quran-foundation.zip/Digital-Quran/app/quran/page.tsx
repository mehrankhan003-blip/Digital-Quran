import Link from "next/link";
import { Search } from "lucide-react";
import { surahs } from "@/data/surahs";

export default function QuranIndexPage() {
  return (
    <main className="mx-auto max-w-5xl px-5 py-12 md:px-8">
      <div className="mb-10">
        <p className="text-sm uppercase tracking-[.2em] text-gold">The Quran</p>
        <h1 className="mt-2 text-4xl font-semibold">114 Surahs</h1>
        <p className="mt-3 max-w-2xl text-ink/55">Choose a Surah to begin. Full canonical Quran data will be connected in the data layer as the project advances.</p>
        <Link href="/search" className="mt-6 inline-flex items-center gap-2 rounded-xl border border-ink/10 bg-white px-4 py-2 text-sm"><Search size={16}/> Search Quran</Link>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        {surahs.map((s) => (
          <Link key={s.number} href={`/quran/${s.number}`} className="flex items-center gap-4 rounded-2xl border border-ink/10 bg-white p-4 transition hover:shadow-soft">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-ivory text-sm text-forest">{s.number}</span>
            <div className="min-w-0 flex-1">
              <div className="font-medium">{s.english}</div>
              <div className="text-xs text-ink/45">{s.translation} · {s.revelation} · {s.ayahs} Ayahs</div>
            </div>
            <span className="quran-arabic text-xl text-forest">{s.arabic}</span>
          </Link>
        ))}
      </div>
    </main>
  );
}
