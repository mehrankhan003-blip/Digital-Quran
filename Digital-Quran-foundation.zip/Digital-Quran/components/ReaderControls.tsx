 "use client";

import { Pause, Play, Repeat2, SlidersHorizontal } from "lucide-react";
import { useState } from "react";

export function ReaderControls() {
  const [playing, setPlaying] = useState(false);

  return (
    <div className="glass sticky top-[4.05rem] z-40 mt-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-ink/10 p-3 shadow-sm">
      <div className="flex items-center gap-2">
        <button onClick={() => setPlaying(!playing)} className="flex h-10 w-10 items-center justify-center rounded-full bg-forest text-white" aria-label={playing ? "Pause" : "Play"}>
          {playing ? <Pause size={17}/> : <Play size={17}/>}
        </button>
        <div>
          <div className="text-sm font-medium">Recitation</div>
          <div className="text-xs text-ink/45">Ayah sync engine</div>
        </div>
      </div>
      <div className="flex items-center gap-1">
        <button className="rounded-xl p-2 text-ink/55 hover:bg-white" aria-label="Repeat"><Repeat2 size={17}/></button>
        <button className="rounded-xl p-2 text-ink/55 hover:bg-white" aria-label="Audio settings"><SlidersHorizontal size={17}/></button>
      </div>
    </div>
  );
}
